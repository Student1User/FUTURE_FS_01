import Portfolio from "../portfolio"
import { ThemeProvider } from "@/components/theme-provider"

export default function Page() {
  return (
    <ThemeProvider defaultTheme="green" attribute="class">
      <Portfolio />
    </ThemeProvider>
  )
}
